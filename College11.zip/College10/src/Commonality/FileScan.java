package Commonality;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

@SuppressWarnings("serial")
public class FileScan implements java.io.Serializable{
	private String SubjectName;
	private byte[] bytefile;
	
	public byte[] getFile() {
		return bytefile;
	}

	public void setFile(byte[] bytefile) {
		this.bytefile = bytefile;
	}

	public String getSubjectName() {
		return SubjectName;
	}

	public void setSubjectName(String subjectName) {
		SubjectName = subjectName;
	}
	
	public FileScan(File file,String SubjectName)
	{
		this.SubjectName=SubjectName;
		byte[] buffer = null;  
        try {    
            FileInputStream fis = new FileInputStream(file);  
            ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);  
            byte[] b = new byte[1000];  
            int n;  
            while ((n = fis.read(b)) != -1) {  
                bos.write(b, 0, n);  
            }  
            fis.close();  
            bos.close();  
            buffer = bos.toByteArray();  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		bytefile=buffer;
	}
}
